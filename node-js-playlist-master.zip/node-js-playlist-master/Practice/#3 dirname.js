// node can also determine the your directory by using '__dirname';

console.log(__dirname);
console.log(__filename);
